# sbpanel 部署指南(新机器)

纯 Python 标准库单文件,无任何 pip 依赖。前提: 目标机已运行 sing-box
(Clash API 默认 `127.0.0.1:9095`),有 systemd 和 python3。

## 步骤

```bash
tar xzf sbpanel-deploy.tar.gz
mkdir -p /opt/sbpanel
cp sbpanel-deploy/app.py          /opt/sbpanel/app.py
cp sbpanel-deploy/sbpanel.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now sbpanel

# 验证
curl -s http://127.0.0.1:8093/api/summary        # 应返回 JSON, HTTP 200
```

配合魔改 zashboard(哨兵页): 用同仓库的 `dist-no-fonts-sbpanel.zip`
作为 sing-box `external_ui`,哨兵页会跨域读本服务,无需其它配置。

## 可选配置(环境变量)

在 `sbpanel.service` 的 `[Service]` 里加 `Environment=` 行(模板里已留注释):

| 变量 | 默认 | 说明 |
|---|---|---|
| `SBPANEL_API` | `http://127.0.0.1:9095` | Clash API 地址 |
| `SBPANEL_DB` | `/vol1/1000/sbpanel/panel.db` | SQLite 路径(**目录不存在会自动创建**) |
| `SBPANEL_PORT` | `8093` | 监听端口 |
| `SBPANEL_LISTEN` | `0.0.0.0` | 监听地址 |

## 注意事项

- **sing-box 服务单元名需为 `sing-box`**: 告警采集走
  `journalctl -u sing-box`,CPU/版本走 `systemctl show sing-box`。
  单元名不同时改 app.py 内对应 subprocess 调用(共 3 处)。
- CORS 头(`Access-Control-Allow-Origin: *`)已内置,哨兵页开箱即用。
- 数据保留策略: dns 明细 30 天 / conn 14 天,daily_stats 与 blocked_domains 永久。
- 端口规划: 8093 是 sbpanel,**8090 留给 beszel 勿占用**。
