#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""sing-box 轻量日志面板 — 单文件, 纯标准库, 旁挂采集"""
import json, re, time, sqlite3, threading, queue, urllib.request, os, socket, subprocess, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

API = os.environ.get("SBPANEL_API", "http://127.0.0.1:9095")
DB = os.environ.get("SBPANEL_DB", "/vol1/1000/sbpanel/panel.db")
PORT = int(os.environ.get("SBPANEL_PORT", "8093"))
LISTEN = os.environ.get("SBPANEL_LISTEN", "0.0.0.0")

# 告警回溯起点: sing-box 服务启动时刻(epoch), 首次采集从此拉全量 warn+ 日志
SB_SINCE = 0
try:
    _t = subprocess.check_output(["systemctl", "show", "sing-box",
                                  "-p", "ActiveEnterTimestamp", "--value"],
                                 text=True, stderr=subprocess.DEVNULL).strip()
    _m = re.search(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}", _t)
    if _m:
        SB_SINCE = int(datetime.datetime.strptime(_m.group(0), "%Y-%m-%d %H:%M:%S").timestamp())
except Exception:
    pass

# ---------- DB ----------
os.makedirs(os.path.dirname(DB) or ".", exist_ok=True)  # 目录不存在自建(新机部署友好)
db = sqlite3.connect(DB, check_same_thread=False)
db.execute("PRAGMA journal_mode=WAL")
db.executescript("""
CREATE TABLE IF NOT EXISTS dns(id INTEGER PRIMARY KEY, ts INT, client TEXT, domain TEXT,
  rtype TEXT, status TEXT);
CREATE INDEX IF NOT EXISTS idx_dns_ts ON dns(ts);
CREATE INDEX IF NOT EXISTS idx_dns_dom ON dns(domain);
CREATE TABLE IF NOT EXISTS conn(id INTEGER PRIMARY KEY, ts INT, client TEXT, host TEXT,
  dst TEXT, network TEXT, chains TEXT, rule TEXT, up INT, down INT, cid_str TEXT);
CREATE UNIQUE INDEX IF NOT EXISTS idx_conn_cid ON conn(cid_str);
""")
try: db.execute("ALTER TABLE dns ADD COLUMN server TEXT")
except Exception: pass
try: db.execute("ALTER TABLE dns ADD COLUMN rtt_ms REAL")
except Exception: pass
try: db.execute("ALTER TABLE dns ADD COLUMN cid TEXT")
except Exception: pass
# 兜底: 同一查询(cid)同秒同记录只落一条, 防日志流重放/双路径重复
try:
    db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uniq_dns_cid ON dns(ts, domain, rtype, status, cid)")
except Exception as e:
    print("uniqidx", e)
db.execute("""CREATE TABLE IF NOT EXISTS devtraffic(
  client TEXT PRIMARY KEY, up INTEGER DEFAULT 0, down INTEGER DEFAULT 0, updated INT)""")
db.execute("""CREATE TABLE IF NOT EXISTS alerts(
  ts INT, level TEXT, payload TEXT, UNIQUE(ts, level, payload))""")
db.execute("CREATE INDEX IF NOT EXISTS idx_alerts_ts ON alerts(ts)")
# 日粒度汇总(永久保留): d=北京日期, q=非拦截查询数, b=拦截次数, bd=去重拦截域名数
db.execute("""CREATE TABLE IF NOT EXISTS daily_stats(
  d TEXT PRIMARY KEY, q INT DEFAULT 0, b INT DEFAULT 0, bd INT DEFAULT 0)""")
# 拦截域名历史总账(永久): 与明细落库同步增量累加, 不受明细保留期影响
db.execute("""CREATE TABLE IF NOT EXISTS blocked_domains(
  domain TEXT PRIMARY KEY, first_ts INT, hits INT DEFAULT 0)""")
DNS_KEEP_DAYS = 30   # dns 明细保留天数
CONN_KEEP_DAYS = 14  # conn 连接历史保留天数
# 启动回填(幂等): 用现存明细补齐总账中缺失的域名, 已存在的行不动防重复计数
db.execute("""INSERT OR IGNORE INTO blocked_domains(domain,first_ts,hits)
              SELECT domain,MIN(ts),COUNT(*) FROM dns
              WHERE status='blocked' AND domain!='' GROUP BY domain""")
db.commit()

def dbw(q, args=()):
    for _ in range(3):
        try:
            db.execute(q, args); db.commit(); return
        except sqlite3.IntegrityError: return
        except sqlite3.OperationalError:
            time.sleep(0.15)
        except Exception as e:
            print("dberr", e); return

def refresh_daily():
    """全量重算 dns 现存数据覆盖到的日期(幂等); 更早日期的汇总行永久保留不动"""
    d0 = int(time.time()) - int(time.time()) % 86400 - 8*3600
    db.execute("""INSERT INTO daily_stats(d,q,b,bd)
        SELECT date(ts,'unixepoch','+8 hours'),
               SUM(status!='blocked'), SUM(status='blocked'),
               COUNT(DISTINCT CASE WHEN status='blocked' AND domain!='' THEN domain END)
        FROM dns WHERE ts>=? GROUP BY 1
        ON CONFLICT(d) DO UPDATE SET q=excluded.q, b=excluded.b, bd=excluded.bd""", (d0,))
    db.commit()

# ---------- collectors ----------
logq = queue.Queue()
CID_RE = re.compile(r"^\[(\d+)\s+([0-9.]+)ms\]")
CLIENT_PATS = [
    re.compile(r"inbound (?:packet )?connection from ([0-9a-fA-F:.]+):\d+"),
    re.compile(r"inbound DNS packet from ([0-9a-fA-F:.]+):\d+"),
]
# 严格匹配新版 sing-box per-answer 行: "dns: cached TYPE domain. TTL IN TYPE IP"
DNS_RE = re.compile(r"dns: (?:optimistic|cached|refreshed) (A|AAAA|CNAME|HTTPS|NS|TXT|MX|SOA|SRV|PTR) ([\w.-]+)\.")
EXCH_RE = re.compile(r"dns: exchange ([\w.-]+)\. IN (\S+)")
MATCH_RE = re.compile(r"dns: match.*=> reject")
ROUTE_RE = re.compile(r"dns: match.*=> (?:route|evaluate)\(([^)]+)\)")
RESP_RE = re.compile(r"=> respond")
# 完成行(带状态词): cached/refreshed/optimistic NOERROR + exchanged <domain> NXDOMAIN/SERVFAIL 等。
# 行前缀 ms 为 sing-box 查询计时起点到该行的耗时; exchanged 完成行前缀差 = 真实上游往返时间(实测国内 35~70ms, 国际 78~110ms)
DONE_ST_RE = re.compile(r"dns: (exchanged|cached|refreshed|optimistic) \S+ ((?:NOERROR|NXDOMAIN|SERVFAIL|REFUSED|FORMERR))")

def _is_done(payload):
    # 注意: "armed[..] response_rcode=.. => respond" 是 sing-box 对客户端的即时响应(fakeip/staged),
    # 出现于真实上游应答之前, 不能当作完成行, 否则 rtt 恒为 1~3ms
    if RESP_RE.search(payload):
        return "armed" not in payload
    return bool(DONE_ST_RE.search(payload) or ("dns: optimistic " in payload and "NOERROR" in payload))

cid_client = {}   # cid -> (client ip, ts)
exch = {}         # cid -> {domain, rtype, ts, ms, servers}
seen_cids = {}    # cid -> ts ; 一个查询(cid)只落库一条 DNS 记录, 防 per-answer 行重复插入
last_sweep = 0

def sweep(now):
    global last_sweep
    if now - last_sweep < 30: return
    last_sweep = now
    for k in [k for k,v in cid_client.items() if now - v[1] > 120]: del cid_client[k]
    for k in [k for k,v in exch.items() if now - v["ts"] > 60]: del exch[k]
    for k in [k for k,v in seen_cids.items() if now - v > 120]: del seen_cids[k]

def handle_log(level, payload):
    global last_sweep
    now = int(time.time())
    m = CID_RE.match(payload)
    cid, ms = (m.group(1), float(m.group(2))) if m else (None, None)
    if cid is None:
        # refreshed lines come without cid wrapper; ignore here
        return
    client = None
    for p in CLIENT_PATS:
        mm = p.search(payload)
        if mm: client = mm.group(1); break
    if client:
        cid_client[cid] = (client, now)
        if now - last_sweep > 30:
            last_sweep = now
            sweep(now)
        return

    em = EXCH_RE.search(payload)
    if em:
        exch[cid] = {"domain": em.group(1).rstrip('.'), "rtype": em.group(2),
                     "ts": now, "ms": ms, "servers": []}
        return
    if MATCH_RE.search(payload):
        # HTTPS/SVCB type rejection - harmless, not an ad block
        return
    if "rule_set=adblock_rules" in payload and "=> predefined" in payload:
        cl = cid_client.get(cid, ("", now))[0]
        e = exch.pop(cid, None)
        if cid not in seen_cids:
            seen_cids[cid] = now
            if cl:  # 无 client 的内部查询不落库
                dbw("INSERT INTO dns(ts,client,domain,rtype,status,cid) VALUES(?,?,?,?,?,?)",
                    (now, cl, e["domain"] if e else "", e["rtype"] if e else "", "blocked", cid))
                bd = e["domain"] if e else ""
                if bd:  # 历史拦截总账同步累加(同一 seen_cids 去重门内, 恰好一次)
                    dbw("INSERT INTO blocked_domains(domain,first_ts,hits) VALUES(?,?,1) "
                        "ON CONFLICT(domain) DO UPDATE SET hits=hits+1", (bd, now))
        return
    rm = ROUTE_RE.search(payload)
    if rm and cid in exch:
        srv = rm.group(1)
        if srv not in exch[cid]["servers"]: exch[cid]["servers"].append(srv)
        return
    # completion: exchanged(真实上游,含NXDOMAIN) / cached|optimistic NOERROR / respond(排除 armed 即时响应)
    done = _is_done(payload)
    if done:
        if cid in exch:
            e = exch.pop(cid)
            cl = cid_client.get(cid, ("", now))[0]
            # 应答状态: NXDOMAIN/SERVFAIL 等标 fail(也是真实上游查询,有真实RTT)
            dm2 = DONE_ST_RE.search(payload)
            ans = dm2.group(2) if dm2 else ""
            if ans in ("NXDOMAIN", "SERVFAIL", "REFUSED", "FORMERR"):
                status = "fail"
            elif "cached" in payload or "optimistic" in payload:
                status = "cache"
            else:
                status = "ok"
            rtt = max(ms - e["ms"], 0.0) if (e["ms"] is not None and ms is not None) else None
            if cid not in seen_cids:
                seen_cids[cid] = now
                if cl:  # 无 client 的内部查询(缓存刷新等)不落库, 不产生"空设备"记录
                    dbw("INSERT INTO dns(ts,client,domain,rtype,status,server,rtt_ms,cid) VALUES(?,?,?,?,?,?,?,?)",
                        (now, cl, e["domain"], e["rtype"], status,
                         ">".join(e["servers"]), rtt, cid))
        elif cid in cid_client:
            seen_cids[cid] = now  # 无 exchange 上下文的完成行: 标记防后续行重复, 不落库
        return
    # fallback: per-answer 行(dns: cached TYPE domain. TTL IN TYPE IP), 仅当 cid 尚未落库
    dm = DNS_RE.search(payload)
    if dm and cid in cid_client and cid not in seen_cids:
        seen_cids[cid] = now
        dbw("INSERT INTO dns(ts,client,domain,rtype,status,cid) VALUES(?,?,?,?,?,?)",
            (now, cid_client[cid][0], dm.group(2).rstrip('.'), dm.group(1), "cache", cid))

REJ_RE = re.compile(r"(reject|refused|blocked)", re.I)
DOMAIN_RE = re.compile(r"([a-z0-9][a-z0-9.-]*\.[a-z]{2,})", re.I)

# ---------- journald alert collector ----------
# 告警以 journald 为权威数据源(sing-box 输出全集): 可回溯历史、重启不丢,
# 不依赖 clash-api 日志流(后者不回溯且断线丢日志)。
ALERT_RE = re.compile(r"[+-]\d{4} (\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) (WARN|WARNING|ERROR) (.*)$", re.S)
# 已知良性 ERROR 降噪(2026-08-26): 两类自愈型噪声, 标记为 level='noise', 不进告警卡/告警列表, 但保留明细。
# ① cloudflared 边缘长连接被 CF 对端断开后秒级自动重连(联通跨境到 Argo 边缘丢包所致);
# ② mux 流被对端以 error code 0(NO_ERROR) 主动取消——远端正常中止, 非故障; 约半数呈每小时:30开始+60s整取消指纹。
BENIGN_RE = re.compile(r"edge connection closed|canceled by remote with error code 0")

def alert_journald():
    while True:
        pa = None
        try:
            last = db.execute("SELECT COALESCE(MAX(ts),0) FROM alerts").fetchone()[0]
            since = max(SB_SINCE, last - 1)
            pa = subprocess.Popen(["journalctl", "-u", "sing-box", "-o", "json",
                                   "-f", "-S", f"@{since}"],
                                  stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=1)
            for raw in pa.stdout:
                try: j = json.loads(raw)
                except Exception: continue
                if j.get("SYSLOG_IDENTIFIER") != "sing-box": continue
                msg = j.get("MESSAGE")
                if isinstance(msg, list):
                    msg = bytes(msg).decode("utf-8", "replace")
                if not isinstance(msg, str): continue
                msg = re.sub(r"\x1b\[[0-9;]*m", "", msg)  # 剥离 ANSI 颜色码
                m = ALERT_RE.search(msg)
                if not m: continue
                tstr, lvl, text = m.group(1), m.group(2), m.group(3).strip()
                if not text: continue
                if BENIGN_RE.search(text): lvl = "noise"  # 已知良性, 降噪保留明细
                try:
                    ts = int(datetime.datetime.strptime(tstr, "%Y-%m-%d %H:%M:%S").timestamp())
                except Exception:
                    ts = int(time.time())
                dbw("INSERT OR IGNORE INTO alerts(ts,level,payload) VALUES(?,?,?)",
                    (ts, "error" if lvl == "ERROR" else "warn", text))
        except Exception as e:
            print("alertjournald", e)
        finally:
            if pa is not None:
                try: pa.kill()
                except Exception: pass
                pa.wait()
        time.sleep(3)

def log_stream(level):
    """single trace stream carries info+debug+error"""
    while True:
        try:
            req = urllib.request.urlopen(f"{API}/logs?level={level}", timeout=None)
            buf = b""
            while True:
                chunk = req.read1(65536)
                if not chunk: break
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    try:
                        j = json.loads(line)
                        logq.put((j.get("type",""), j.get("payload","")))
                    except Exception: pass
        except Exception as e:
            print("logstream", level, e); time.sleep(3)

# live connection traffic accounting
prev_traffic = {}  # clash cid -> (up, down)

def conn_poll():
    while True:
        try:
            j = json.loads(urllib.request.urlopen(f"{API}/connections", timeout=5).read())
            now = int(time.time())
            conns = j.get("connections") or []
            live_now = {}
            for c in conns:
                cid = c["id"]; md = c.get("metadata", {})
                up, down = c.get("upload",0), c.get("download",0)
                host = md.get("host") or md.get("sniffHost") or ""
                cli = md.get("sourceIP","")
                live_now[cid] = True
                cur = prev_traffic.get(cid)
                if cur is None:
                    # first sighting: store baseline; also record row for history
                    dbw("INSERT OR IGNORE INTO conn(ts,client,host,dst,network,chains,rule,up,down,cid_str) VALUES(?,?,?,?,?,?,?,?,?,?)",
                        (now, cli, host, f"{md.get('destinationIP','')}:{md.get('destinationPort','')}",
                         md.get("network",""), ">".join(c.get("chains",[])), c.get("rule",""),
                         0, 0, cid))
                    prev_traffic[cid] = (up, down, cli)
                else:
                    dup = up - cur[0]; ddown = down - cur[1]
                    if dup > 0 or ddown > 0:
                        dbw("""INSERT INTO devtraffic(client,up,down,updated) VALUES(?,?,?,?)
                               ON CONFLICT(client) DO UPDATE SET up=up+?, down=down+?, updated=?""",
                            (cli, dup, ddown, now, dup, ddown, now))
                    prev_traffic[cid] = (up, down, cli)
            # connections that disappeared: credit their final totals
            gone = [k for k in prev_traffic if k not in live_now]
            for g in gone:
                prev_traffic.pop(g, None)
            # prune stale seen entries to bound memory
            if len(prev_traffic) > 5000:
                prev_traffic.clear()
        except Exception as e:
            print("connpoll", e)
        time.sleep(3)

def collector():
    threading.Thread(target=log_stream, args=("trace",), daemon=True).start()
    threading.Thread(target=conn_poll, daemon=True).start()
    threading.Thread(target=alert_journald, daemon=True).start()
    while True:
        lvl, payload = logq.get()
        try:
            handle_log(lvl, payload)
        except Exception as e: print("handle", e)

threading.Thread(target=collector, daemon=True).start()

def maint():
    # 每 5 分钟重算日汇总(毫秒级); 每小时检查一次, 每天实际执行一次明细清理
    last_ph = 0
    while True:
        try:
            refresh_daily()
            ph = int(time.time()) // 3600
            if ph != last_ph:
                last_ph = ph
                cut = int(time.time())
                db.execute("DELETE FROM dns WHERE ts<?", (cut - DNS_KEEP_DAYS*86400,))
                db.execute("DELETE FROM conn WHERE ts<?", (cut - CONN_KEEP_DAYS*86400,))
                db.commit()
        except Exception as e:
            print("maint", e)
        time.sleep(300)

threading.Thread(target=maint, daemon=True).start()

# ---------- web ----------
# sing-box 版本号(clash-api /version, 10 分钟缓存; sing-box 升级重启后自动跟随)
VER = ""
_ver_ts = 0
def get_ver():
    global VER, _ver_ts
    if time.time() - _ver_ts > 600:
        try:
            j = json.loads(urllib.request.urlopen(f"{API}/version", timeout=3).read())
            v = str(j.get("version") or "").replace("sing-box", "").strip()
            VER = ("v" + v) if v else ""
        except Exception:
            VER = ""
        _ver_ts = time.time()
    return VER

# ---------- 系统内存(/proc/meminfo, 5 秒节流) ----------
_mem_cache = (0.0, None)
def sys_mem():
    """返回系统内存用量。used 采用 MemTotal-MemAvailable(不含 cache/buff, 与 free -h 的 used 口径一致)。"""
    global _mem_cache
    now = time.time()
    if now - _mem_cache[0] < 5 and _mem_cache[1] is not None:
        return _mem_cache[1]
    try:
        mi = {}
        with open("/proc/meminfo") as f:
            for line in f:
                k, _, v = line.partition(":")
                if k in ("MemTotal", "MemAvailable"):
                    mi[k] = int(v.split()[0]) * 1024   # kB -> bytes
                    if len(mi) == 2:
                        break
        total = mi.get("MemTotal")
        avail = mi.get("MemAvailable")
        if not total or avail is None:
            raise ValueError("meminfo incomplete")
        used = total - avail
        out = {"mem_total": total, "mem_used": used,
               "mem_pct": round(used / total * 100, 1)}
    except Exception:
        out = {"mem_total": None, "mem_used": None, "mem_pct": None}
    _mem_cache = (now, out)
    return out

# ---------- sing-box 进程资源(CPU 瞬时占用差分 / RSS, 5 秒节流) ----------
_sb_pid = 0
_sb_prev = None               # (wall, jiffies) CPU 差分基线
_sb_cache = (0.0, None, None) # (ts, cpu%, rss_bytes) 节流缓存
def sb_res():
    global _sb_pid, _sb_prev, _sb_cache
    now = time.time()
    if now - _sb_cache[0] < 5:
        return {"sb_cpu": _sb_cache[1], "sb_ram": _sb_cache[2]}
    try:
        if _sb_pid <= 0:
            _sb_pid = int(subprocess.check_output(
                ["systemctl", "show", "sing-box", "-p", "MainPID", "--value"],
                text=True, stderr=subprocess.DEVNULL).strip() or 0)
        with open(f"/proc/{_sb_pid}/stat") as f:
            p = f.read().rsplit(")", 1)[1].split()
        jiffies = int(p[11]) + int(p[12])          # utime + stime
        hz = os.sysconf("SC_CLK_TCK")
        cpu = None
        if _sb_prev and now - _sb_prev[0] >= 1:
            cpu = max((jiffies - _sb_prev[1]) / hz / (now - _sb_prev[0]) * 100, 0.0)
        if _sb_prev is None or cpu is not None:
            _sb_prev = (now, jiffies)              # 首次建基线, 之后随采样推进
        rss = None
        with open(f"/proc/{_sb_pid}/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    rss = int(line.split()[1]) * 1024
                    break
        _sb_cache = (now, round(cpu, 2) if cpu is not None else None, rss)
    except Exception:
        _sb_pid = 0                                # sing-box 重启后重新定位 PID
        _sb_prev = None
        _sb_cache = (now, None, None)
    return {"sb_cpu": _sb_cache[1], "sb_ram": _sb_cache[2]}

PAGE = """<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>sing-box 状态面板</title>
<style>
:root{--bg:#0f1115;--card:#171a21;--fg:#e6e9ef;--mut:#8b93a7;--acc:#4f8cff;--red:#ff5c5c;--grn:#3fbf7f;--bd:#262b36}
*{box-sizing:border-box;margin:0}
body{background:var(--bg);color:var(--fg);font:14px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif;padding:16px}
h1{font-size:18px;margin-bottom:12px}h1 small{color:var(--mut);font-size:12px;font-weight:normal}
.htop{width:100%;border-collapse:collapse;margin-bottom:12px}
.htop td{vertical-align:middle;padding:0;border-bottom:none}
.htop td.t1{font-size:18px}
.htop td.t1 small{color:var(--mut);font-size:12px;font-weight:normal}
.htop td.t2{text-align:right}
table.rt{border-collapse:collapse;display:inline-table;vertical-align:middle}
.rt td{padding:1px 0 1px 6px;font-size:12px;line-height:20px;color:var(--mut);white-space:nowrap;border-bottom:none;vertical-align:middle;background:none}
.rt td.v{text-align:right;width:56px;color:var(--grn);font-variant-numeric:tabular-nums;font-weight:600}
.rt td.upd{padding-left:10px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:14px}
.card{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:12px}
.card .v{font-size:22px;font-weight:600}.card .l{color:var(--mut);font-size:12px}
.card.r .v{color:var(--red)}.card.g .v{color:var(--grn)}
.card.link{cursor:pointer}.card.link:hover{border-color:var(--acc)}
table{width:100%;border-collapse:collapse;background:var(--card);border-radius:10px;overflow:hidden}
th,td{text-align:left;padding:7px 10px;border-bottom:1px solid var(--bd);font-size:13px}
th{color:var(--mut);font-weight:500;background:#14171e;position:sticky;top:0}
td.mut{color:var(--mut)} .blk{color:var(--red)} .ok{color:var(--grn)} .cac{color:#d9a53f}
input,select{background:#10131a;border:1px solid var(--bd);color:var(--fg);padding:7px 10px;border-radius:8px}
input{width:260px}
.view{display:none}.view.on{display:block}
.barwrap{background:#10131a;border-radius:4px;height:8px;width:120px;display:inline-block;vertical-align:middle}
.trend{display:flex;align-items:flex-end;gap:4px;height:96px;background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:10px 12px 6px}
.trend:empty{display:none}
.trend .tb{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;min-width:0}
.trend .bar{width:62%;max-width:28px;background:linear-gradient(180deg,var(--red),#8c2f2f);border-radius:3px 3px 0 0}
.trend .bl{font-size:9px;color:var(--mut);margin-top:3px;white-space:nowrap}
.trend .bv{font-size:9px;color:var(--fg);margin-bottom:2px}
@media(max-width:600px){td,th{padding:5px 6px}}
</style></head><body>
<table class="htop"><tr>
<td class="t1">sing-box 状态面板 <small id="ver"></small></td>
<td class="t2"><table class="rt"><tr>
<td>CPU</td><td class="v" id="k_cpu">-</td><td class="upd" rowspan="2" id="upd"></td></tr><tr>
<td>RAM</td><td class="v" id="k_ram">-</td></tr></table></td>
</tr></table>
<div class="grid">
<div class="card link" onclick="tab('v_dns');loadDns()"><div class="v" id="k_q">-</div><div class="l">今日 DNS 查询 ▸</div><div class="l" id="k_qt"></div></div>
<div class="card r link" onclick="tab('v_blk');showBlk()"><div class="v" id="k_b">-</div><div class="l">拦截域名数 (今日) ▸</div><div class="l" id="k_bt"></div></div>
<div class="card g link" onclick="tab('v_dev')"><div class="v" id="k_d">-</div><div class="l">活跃设备 (1h) ▸</div></div>
<div class="card link" onclick="tab('v_con');loadConns()"><div class="v" id="k_c">-</div><div class="l">当前连接数 ▸</div></div>
<div class="card link" onclick="tab('v_tra');loadTra()"><div class="v" id="k_t">-</div><div class="l">累计流量 ▸</div></div>
<div class="card link" onclick="tab('v_alr');loadAlerts()"><div class="v" id="k_r2">-<span id="k_r" style="display:none"></span></div><div class="l">日志告警 ▸</div></div>
</div>
<div class="view on" id="v_dev"><table id="t_dev"><thead><tr>
<th>设备 IP</th><th>查询数</th><th>拦截数</th><th>连接数</th><th>最近活跃</th><th>Top 域名</th></tr></thead><tbody></tbody></table></div>

<div class="view" id="v_dns"><p style="margin-bottom:8px;display:flex;gap:8px;flex-wrap:wrap">
<input id="s_dns" placeholder="搜索域名/IP…" oninput="loadDns()" style="flex:1;min-width:160px">
<select id="f_rtype" onchange="loadDns()"><option value="">类型:全部</option><option>A</option><option>AAAA</option><option>CNAME</option><option>HTTPS</option></select>
<select id="f_status" onchange="loadDns()"><option value="">状态:全部</option><option value="ok">ok</option><option value="cache">cache</option><option value="fail">fail</option></select>
<select id="f_server" onchange="loadDns()"><option value="">服务器:全部</option><option value="cn-ali">cn-ali</option><option value="cn-tencent">cn-tencent</option><option value="global-cloudflare">global-cloudflare</option><option value="fakeip">fakeip</option></select>
</p>
<table id="t_dns"><thead><tr><th>时间</th><th>设备</th><th>域名</th><th>类型</th><th>状态</th><th>DNS 服务器</th><th>RTT</th></tr></thead><tbody></tbody></table></div>

<div class="view" id="v_blk"><p style="margin-bottom:8px;display:flex;gap:8px;flex-wrap:wrap">
<input id="s_blk" placeholder="搜索域名…" oninput="showBlk()" style="flex:1;min-width:160px">
<select id="f_blkdev" onchange="showBlk()"><option value="">设备:全部</option></select>
<select id="f_blkdays" onchange="showBlk()"><option value="">今日</option><option value="7">近7天</option><option value="30">近30天</option><option value="all">全部</option></select>
</p>
<div id="blk_trend" style="margin-bottom:10px"></div>
<p style="color:var(--mut);margin-bottom:8px" id="blk_note"></p>
<table id="t_blk"><thead><tr><th>#</th><th>域名</th><th>拦截设备</th><th>次数</th><th></th></tr></thead><tbody></tbody></table></div>

<div class="view" id="v_con"><p style="margin-bottom:8px"><input id="s_con" placeholder="搜索设备/目标/节点…" oninput="loadConns()"></p>
<table id="t_con"><thead><tr>
<th>设备</th><th>目标</th><th>网络</th><th>链路</th><th>↑/↓</th></tr></thead><tbody></tbody></table></div>

<div class="view" id="v_tra">
<table id="t_tra"><thead><tr><th>设备 IP</th><th>上传</th><th>下载</th><th>合计</th><th>占比</th><th>最近活跃</th></tr></thead><tbody></tbody></table></div>

<div class="view" id="v_alr"><p style="color:var(--mut);margin-bottom:8px">warn 及以上级别的 sing-box 日志（保留最近 300 条，实时刷新）</p>
<table id="t_alr"><thead><tr><th>时间</th><th>级别</th><th>内容</th></tr></thead><tbody></tbody></table></div>

<script>
const $=s=>document.querySelector(s);
function fmtB(n){if(n>1e9)return(n/1e9).toFixed(2)+' GB';if(n>1e6)return(n/1e6).toFixed(1)+' MB';if(n>1e3)return(n/1e3).toFixed(0)+' KB';return n+' B'}
function fmtN(n){return (n||0).toLocaleString()}
function esc(s){return String(s??'').replace(/[<>&]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;'})[c])}
function tab(id){document.querySelectorAll('.view').forEach(v=>v.classList.remove('on'));$('#'+id).classList.add('on');refresh()}
async function refresh(){
 const s=await(await fetch('/api/summary')).json();
 $('#k_q').textContent=s.today_queries;$('#k_b').textContent=s.today_blocked;
 $('#k_qt').textContent='累计 '+fmtN(s.total_queries)+' 次';
 $('#k_bt').textContent='累计 '+fmtN(s.total_blocked)+' 域名 · '+fmtN(s.total_blocked_hits)+' 次';
 $('#k_d').textContent=s.active_devices;$('#k_t').textContent=fmtB(s.total_traffic);
 $('#k_c').textContent=s.conns;
 $('#k_r2').firstChild.textContent = s.alerts!=null&&s.alerts>0 ? s.alerts : '-';
 $('#ver').textContent=s.ver||'';
 $('#k_cpu').textContent=s.sb_cpu!=null?s.sb_cpu.toFixed(2)+'%':'-';
 $('#k_ram').textContent=s.sb_ram!=null?(s.sb_ram/1048576).toFixed(s.sb_ram>=52428800?0:1)+'M':'-';
 $('#upd').textContent='更新于 '+new Date().toLocaleTimeString();
 if($('#v_dev').classList.contains('on')){const r=await(await fetch('/api/devices')).json();
  $('#t_dev tbody').innerHTML=r.map(d=>`<tr><td>${esc(d.ip)}</td><td>${d.queries}</td><td class="${d.blocked?'blk':'mut'}">${d.blocked}</td><td>${d.conns}</td><td class="mut">${d.last_seen}</td><td class="mut">${esc(d.top)}</td></tr>`).join('')}
 if($('#v_dns').classList.contains('on'))await loadDns();
 if($('#v_blk').classList.contains('on'))await showBlk();
 if($('#v_con').classList.contains('on'))await loadConns();
 if($('#v_tra').classList.contains('on'))await loadTra();
 if($('#v_alr').classList.contains('on'))await loadAlerts();
}
async function loadConns(){const q=($('#s_con')?.value||'').toLowerCase();
 const r=await(await fetch('/api/conns')).json();
 const f=r.filter(c=>!q||(c.client+' '+(c.host||'')+' '+c.dst+' '+c.chains).toLowerCase().includes(q));
 $('#t_con tbody').innerHTML=f.length?f.map(c=>`<tr><td>${esc(c.client)}</td><td>${esc(c.host)||'<span class=mut>'+esc(c.dst)+'</span>'}</td><td class="mut">${c.network}</td><td class="mut">${esc(c.chains)}</td><td class="mut">${fmtB(c.up)} / ${fmtB(c.down)}</td></tr>`).join(''):'<tr><td colspan=5 class=mut>无匹配连接</td></tr>'}
async function loadAlerts(){const r=await(await fetch('/api/alerts')).json();
 $('#t_alr tbody').innerHTML=r.length?r.map(x=>`<tr><td class="mut">${x.time}</td><td class="${x.level=='error'?'blk':'cac'}">${x.level}</td><td style="word-break:break-all">${esc(x.text)}</td></tr>`).join(''):'<tr><td colspan=3 class=mut>暂无告警</td></tr>'}
async function loadDns(){const q=$('#s_dns').value,rt=$('#f_rtype').value,st=$('#f_status').value,sv=$('#f_server').value;
 const r=await(await fetch('/api/dns?q='+encodeURIComponent(q))).json();
 let f=r.filter(x=>(!rt||x.rtype==rt)&&(!st||x.status==st)&&(!sv||(x.server||'')==sv));
 // A/AAAA 折叠: 类型过滤为"全部"时, 同秒同设备同域名的 A/AAAA 合并为一行(仅展示层, 数据不变)
 if(!rt){
  const g=new Map();
  for(const x of f){const k=x.time+'|'+x.client+'|'+x.domain;if(!g.has(k))g.set(k,[]);g.get(k).push(x)}
  f=[];
  for(const grp of g.values()){
   const aa=grp.filter(x=>x.rtype=='A'||x.rtype=='AAAA');
   if(aa.length>=2){
    const a=aa.find(x=>x.rtype=='A')||aa[0];
    f.push(Object.assign({},a,{rtype:[...new Set(aa.map(x=>x.rtype))].sort().join('/')}));
    f.push(...grp.filter(x=>x.rtype!='A'&&x.rtype!='AAAA'));
   }else f.push(...grp);
  }
 }
 // RTT: ok/fail 为真实上游往返耗时; cache 无网络往返显示 -
 $('#t_dns tbody').innerHTML=f.length?f.map(x=>`<tr><td class="mut">${x.time}</td><td>${esc(x.client)}</td><td>${esc(x.domain)}</td><td class="mut">${x.rtype}</td><td class="${x.status=='ok'?'ok':(x.status=='fail'?'blk':'cac')}">${x.status}</td><td class="mut">${esc(x.server)||'-'}</td><td class="mut" title="${x.status=='cache'?'缓存命中,无网络往返':'真实上游查询耗时'}">${x.status!='cache'&&x.rtt!=null?x.rtt+' ms':'-'}</td></tr>`).join(''):'<tr><td colspan=7 class=mut>无匹配记录</td></tr>'}
let blkDevsLoaded=false;
const DAY_LB={'':'今日','7':'近7天','30':'近30天','all':'全部'};
async function showBlk(){const q=($('#s_blk')?.value||'').toLowerCase(),dv=$('#f_blkdev').value,dy=$('#f_blkdays')?.value||'';
 const qp=new URLSearchParams();if(dv)qp.set('client',dv);if(dy)qp.set('days',dy);
 const r=await(await fetch('/api/blocked?'+qp)).json();
 if(!blkDevsLoaded&&r.devices){const sel=$('#f_blkdev');const cur=sel.value;
  sel.innerHTML='<option value="">设备:全部</option>'+r.devices.map(d=>`<option${d==cur?' selected':''}>${esc(d)}</option>`).join('');blkDevsLoaded=true}
 loadTrend();
 const rows=(q?r.rows.filter(x=>x.d.toLowerCase().includes(q)):r.rows);
 $('#blk_note').textContent=`${DAY_LB[dy]||dy}｜匹配 ${rows.length} / ${r.unique} 个域名（总计 ${fmtN(r.total)} 次拦截）`;
 $('#t_blk tbody').innerHTML=rows.length?rows.map((x,i)=>`<tr><td class="mut">${i+1}</td><td class="blk">${esc(x.d)}</td><td class="mut">${esc(x.clients)||'-'}</td><td>${x.n}</td><td><span class="barwrap"><span style="width:${Math.max(2,x.pct)}%;background:var(--red);display:inline-block;height:8px;border-radius:4px"></span></span></td></tr>`).join(''):'<tr><td colspan=5 class=mut>无匹配域名</td></tr>'}
async function loadTrend(){const r=await(await fetch('/api/daily')).json();
 const days=r.slice(0,14).reverse();const mx=Math.max(...days.map(x=>x.b),1);
 $('#blk_trend').innerHTML='<div class="trend">'+days.map(x=>`<div class="tb" title="${x.d}：拦截 ${x.b} 次 / ${x.bd} 个域名"><div class="bv">${x.b}</div><div class="bar" style="height:${Math.max(4,Math.round(x.b/mx*100))}%"></div><div class="bl">${x.d.slice(5)}</div></div>`).join('')+'</div>'}
async function loadTra(){const r=await(await fetch('/api/devtraffic')).json();
 const tot=r.reduce((a,x)=>a+x.up+x.down,0)||1;
 $('#t_tra tbody').innerHTML=r.length?r.map(x=>`<tr><td>${esc(x.client)}</td><td>${fmtB(x.up)}</td><td>${fmtB(x.down)}</td><td>${fmtB(x.up+x.down)}</td><td><span class="barwrap"><span style="width:${Math.max(2,(x.up+x.down)/tot*100)}%;background:var(--acc);display:inline-block;height:8px;border-radius:4px"></span></span></td><td class="mut">${x.updated}</td></tr>`).join(''):'<tr><td colspan=6 class=mut>流量从面板启动后开始累计</td></tr>'}
refresh();setInterval(refresh,10000);
</script></body></html>"""

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _json(self, obj):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(200); self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)
    # --- CORS patch (sbpanel-zashboard 魔改配套) ---
    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        BaseHTTPRequestHandler.end_headers(self)
    def do_GET(self):
        p, _, qs = self.path.partition("?")
        args = dict(a.split("=",1) for a in qs.split("&") if "=" in a)
        now = int(time.time())
        day0 = now - now % 86400 - 8*3600  # 北京时间当日零点(UTC+8)
        if p == "/":
            b = PAGE.encode(); self.send_response(200)
            self.send_header("Content-Type","text/html; charset=utf-8")
            self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)
        elif p == "/api/summary":
            tq = db.execute("SELECT COUNT(*) FROM dns WHERE ts>? AND status!='blocked'", (day0,)).fetchone()[0]
            tb = db.execute("SELECT COUNT(DISTINCT domain) FROM dns WHERE ts>? AND status='blocked' AND domain!=''", (day0,)).fetchone()[0]
            ad = db.execute("SELECT COUNT(DISTINCT client) FROM dns WHERE ts>?", (now-3600,)).fetchone()[0]
            tt = db.execute("SELECT COALESCE(SUM(up),0)+COALESCE(SUM(down),0) FROM devtraffic").fetchone()[0]
            art = db.execute("SELECT AVG(rtt_ms) FROM dns WHERE ts>? AND rtt_ms IS NOT NULL AND status IN ('ok','fail')", (day0,)).fetchone()[0]
            nc = "-"
            try:
                j = json.loads(urllib.request.urlopen(f"{API}/connections", timeout=3).read())
                nc = len(j.get("connections") or [])
            except Exception: pass
            tq_all = db.execute("SELECT COALESCE(SUM(q),0) FROM daily_stats").fetchone()[0]
            bd_all = db.execute("SELECT COUNT(*),COALESCE(SUM(hits),0) FROM blocked_domains").fetchone()
            self._json({"today_queries":tq,"today_blocked":tb,"active_devices":ad,
                        "total_traffic":tt,"conns":nc,"avg_rtt":round(art,1) if art else None,
                        "total_queries":tq_all,"total_blocked":bd_all[0],"total_blocked_hits":bd_all[1],
                        "alerts":db.execute("SELECT COUNT(*) FROM alerts WHERE level!='noise'").fetchone()[0],
                        "today_alerts":db.execute("SELECT COUNT(*) FROM alerts WHERE level!='noise' AND ts>=?",(day0,)).fetchone()[0],
                        "ver":get_ver(),**sb_res(),**sys_mem()})
        elif p == "/api/devices":
            rows = db.execute("""SELECT client,
                SUM(status!='blocked'), SUM(status='blocked'),
                MAX(ts) FROM dns GROUP BY client""").fetchall()
            conns = {r[0]:r[1] for r in db.execute("SELECT client,COUNT(*) FROM conn GROUP BY client")}
            tops2 = {}
            for c,d,n in db.execute("SELECT client,domain,COUNT(*) n FROM dns WHERE ts>? GROUP BY client,domain ORDER BY n DESC LIMIT 500",(now-86400,)):
                tops2.setdefault(c,[]).append((d,n))
            out=[]
            for ip,q,b,last in rows:
                t = ", ".join(d for d,_ in (tops2.get(ip) or [])[:3])
                out.append({"ip":ip,"queries":q,"blocked":b,"conns":conns.get(ip,0),
                    "last_seen":time.strftime("%H:%M:%S",time.localtime(last)),"top":t})
            out.sort(key=lambda x:-x["queries"])
            self._json(out)
        elif p == "/api/dns":
            q = args.get("q","")
            lim = 300
            base = "FROM dns WHERE status!='blocked'"
            if q:
                rows = db.execute(f"SELECT ts,client,domain,rtype,status,server,rtt_ms {base} AND (domain LIKE ? OR client LIKE ?) ORDER BY ts DESC LIMIT ?",
                    (f"%{q}%",f"%{q}%",lim)).fetchall()
            else:
                rows = db.execute(f"SELECT ts,client,domain,rtype,status,server,rtt_ms {base} ORDER BY ts DESC LIMIT ?",(lim,)).fetchall()
            self._json([{"time":time.strftime("%H:%M:%S",time.localtime(t)),"client":c,"domain":d,
                         "rtype":r,"status":s,"server":sv,"rtt":None if rt is None else round(rt,1)}
                        for t,c,d,r,s,sv,rt in rows])
        elif p == "/api/blocked":
            cfilt = args.get("client","")
            dv = args.get("days","")   # ""=今日 / 7 / 30 / all(全部历史) / YYYY-MM-DD(指定北京单日)
            if dv == "all":
                t0, t1 = 0, None
            elif dv in ("7","30"):
                t0, t1 = day0 - (int(dv)-1)*86400, None
            elif re.match(r"^\d{4}-\d{2}-\d{2}$", dv):
                try:
                    t0 = int(datetime.datetime.strptime(dv, "%Y-%m-%d").replace(
                        tzinfo=datetime.timezone(datetime.timedelta(hours=8))).timestamp())
                    t1 = t0 + 86400   # 单日: 上界为次日零点(北京)
                except ValueError:
                    t0, t1 = day0, day0 + 86400
            else:
                t0, t1 = day0, day0 + 86400
            conds = ["status='blocked'", "domain!=''", "ts>=?"]
            params = [t0]
            if t1 is not None:
                conds.append("ts<?")
                params.append(t1)
            if cfilt:
                conds.append("client=?")
                params.append(cfilt)
            where = " AND ".join(conds)
            top = db.execute(f"SELECT domain,COUNT(*) n FROM dns WHERE {where} GROUP BY domain ORDER BY n DESC",params).fetchall()
            uniq = db.execute(f"SELECT COUNT(DISTINCT domain) FROM dns WHERE {where}",params).fetchone()[0]
            tot = sum(n for _,n in top)
            mx = top[0][1] if top else 1
            cb = {}
            for d,c,n in db.execute(f"SELECT domain,client,COUNT(*) n FROM dns WHERE {where} GROUP BY domain,client ORDER BY n DESC LIMIT 3000",params):
                cb.setdefault(d,[]).append(c)
            devs = [r[0] for r in db.execute("SELECT DISTINCT client FROM dns WHERE status='blocked' AND client!='' AND ts>=? AND ts<? ORDER BY 1",(t0,t1 or now+1))]
            self._json({"unique":uniq,"total":tot,"devices":devs,
                "rows":[{"d":d,"n":n,"pct":round(n/mx*100),
                         "clients":", ".join(cb.get(d,[])[:3])} for d,n in top]})
        elif p == "/api/blocked/recent":
            # 实时拦截事件流: 按时间倒序的原始拦截明细(默认今日, 可指定北京单日), 供前端详情页展示
            lim = int(args.get("limit", "200"))
            lim = max(10, min(lim, 500))
            cfilt = args.get("client", "")
            dv = args.get("days", "")
            if re.match(r"^\d{4}-\d{2}-\d{2}$", dv):
                try:
                    t0 = int(datetime.datetime.strptime(dv, "%Y-%m-%d").replace(
                        tzinfo=datetime.timezone(datetime.timedelta(hours=8))).timestamp())
                except ValueError:
                    t0 = day0
            else:
                t0 = day0
            t1 = t0 + 86400
            conds = ["status='blocked'", "domain!=''", "ts>=?", "ts<?"]
            params = [t0, t1]
            if cfilt:
                conds.append("client=?")
                params.append(cfilt)
            where = " AND ".join(conds)
            total = db.execute(f"SELECT COUNT(*) FROM dns WHERE {where}", params).fetchone()[0]
            uniq = db.execute(f"SELECT COUNT(DISTINCT domain) FROM dns WHERE {where}", params).fetchone()[0]
            devs = [r[0] for r in db.execute("SELECT DISTINCT client FROM dns WHERE status='blocked' AND client!='' AND ts>=? AND ts<? ORDER BY 1", (t0, t1))]
            rows = db.execute(f"""SELECT ts,client,domain FROM dns
                WHERE {where}
                ORDER BY ts DESC LIMIT ?""", (*params, lim)).fetchall()
            self._json({"total": total, "unique": uniq, "devices": devs,
                "rows": [{"time": time.strftime("%H:%M:%S", time.localtime(t)),
                          "client": c, "domain": d} for t, c, d in rows]})
        elif p == "/api/daily":
            self._json([{"d":d,"q":q,"b":b,"bd":bd}
                        for d,q,b,bd in db.execute(
                            "SELECT d,q,b,bd FROM daily_stats ORDER BY d DESC LIMIT 90")])
        elif p == "/api/conns":
            try:
                j = json.loads(urllib.request.urlopen(f"{API}/connections", timeout=4).read())
                out=[{"client":c["metadata"].get("sourceIP",""),"host":c["metadata"].get("host",""),
                      "dst":f'{c["metadata"].get("destinationIP","")}:{c["metadata"].get("destinationPort","")}',
                      "network":c["metadata"].get("network",""),"chains":">".join(c.get("chains",[])),
                      "up":c.get("upload",0),"down":c.get("download",0)} for c in j.get("connections") or []]
                out.sort(key=lambda x:-(x["up"]+x["down"]))
                self._json(out[:200])
            except Exception:
                self._json([])
        elif p == "/api/alerts":
            rows = db.execute("SELECT ts,level,payload FROM alerts WHERE level!='noise' ORDER BY ts DESC LIMIT 300").fetchall()
            self._json([{"time":time.strftime("%H:%M:%S",time.localtime(t)),"level":lv,
                         "text":tx} for t,lv,tx in rows])
        elif p == "/api/devtraffic":
            rows = db.execute("SELECT client,up,down,updated FROM devtraffic ORDER BY up+down DESC").fetchall()
            self._json([{"client":c,"up":u,"down":d,
                         "updated":time.strftime("%H:%M:%S",time.localtime(t))} for c,u,d,t in rows])
        else:
            self.send_response(404); self.end_headers()

if __name__ == "__main__":
    srv = ThreadingHTTPServer((LISTEN, PORT), H)
    print(f"sb-panel listening on :{PORT}")
    srv.serve_forever()
